/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn29;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class TN29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int test = Integer.parseInt(sc.nextLine());
        while(test-- >0){
            Queue <Integer> pq = new PriorityQueue<>(new Comparator<Integer>(){
                @Override
                public int compare(Integer o1, Integer o2) {
                    return o2.compareTo(o1);
                }
                
            });
            int k = Integer.parseInt(sc.nextLine());
            String line = sc.nextLine();
            int cnt[] = new int[26];
            for(char ele:line.toCharArray()){
                cnt[ele-'A'] += 1;
            }
            for(int i=0;i<26;i++){
                if(cnt[i]!=0){
                    pq.offer(cnt[i]);
                }
            }
            while(k-- >0){
                pq.offer(pq.poll()-1);
            }
            long ans = 0;
            for(int ele:pq){
                ans += ele*ele;
            }
            System.out.println(ans);
        }
    }
    
}
